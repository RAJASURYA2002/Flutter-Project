//
//  Generated file. Do not edit.
//

import FlutterMacOS
import Foundation

import awesome_notifications

func RegisterGeneratedPlugins(registry: FlutterPluginRegistry) {
  AwesomeNotificationsPlugin.register(with: registry.registrar(forPlugin: "AwesomeNotificationsPlugin"))
}
